import React from 'react';
export class Home extends React.Component {
    constructor(props) {
      super(props);
    }
    render() {
      return (
        <div className="ui_top" >
        <div className="textblock"> 
            Solo
            <br/>
            Play the classic game against yourself. 
        </div>
    </div>
      );
    }
  }