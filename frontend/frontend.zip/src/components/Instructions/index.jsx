import React from 'react';
export class Instructions extends React.Component {
    constructor(props) {
      super(props);
    }
    render() {
      return (
        <div className="ui_top" >
        <div className="textblock"> 
            Take a look a mordle.io instructions.
        </div>
    </div>
      );
    }
  }